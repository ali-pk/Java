import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
 
public class Connectivity {
   
     public static Connection getConnection(){
        try{
             Connection conn=null;
    String dbURL = "jdbc:ucanaccess://D:\\BankManagementSystem.accdb"; 
   
				Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
             			conn = DriverManager.getConnection(dbURL); 
				return conn;
	   			 }
				catch(Exception e)
				{		
					JOptionPane.showMessageDialog(null, e);
				}
        return null;
        }
}
