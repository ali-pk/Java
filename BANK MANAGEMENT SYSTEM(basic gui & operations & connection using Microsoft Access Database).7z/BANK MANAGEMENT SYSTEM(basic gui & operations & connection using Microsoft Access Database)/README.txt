About this Project:
	1) This is the Bank Management System created using GUI, this project is having basic 	   operations (i.e. for deposit and withdrawl)
	2) We used Microsoft Access Database as the database for this project which is 		   connected using UcanAccess library.
	3) As this folder exceeds the number of files (i.e. 100+), so I have to zip the 		   folder to upload it to github. Sorry for inconvenience.